import React, { Component } from 'react';
import logo from './logo.svg';
import EmailComponent, { c } from './Email';
import faker from 'faker'
import store from './store';

const ShowWhen = (props) => props.condition ? props.children : null;

class EamilLogin extends Component {
    state = {
        username: "",
        password: "",
        loginForm: {
            loading: true,
            error: ""
        }
    }
    constructor() {
        super();
        this.setState(this.state);
    }
    handleChange(key, e) {
        this.setState({ [key]: e.target.value });
    }

    handleLogin() {
        // if (this.state.username == 'ivp' && this.state.password == 'ivp') {
        //     this.setState({ isError: null });
        //     this.props.onLogin();
        // } else {
        //     this.setState({ isError: "username and password is incorrect" });
        // }
        store.dispatch({ type: 'LOGIN_STARTED' });
        this.login(this.state.username, this.state.password).then(value => {
            if (value.status === 'success') {
                // this.handleLoginComplete();
                // this.setState({ isError: null });
                store.dispatch({ type: 'LOGIN_COMPLETED' });
            } else {
                store.dispatch({ type: 'LOGIN_FAILED' });

            }
            console.log(value);
        })

    }
    componentDidMount() {
        store.subscribe(() => {
            console.log(store.getState())
            this.setState(store.getState());
        })
    }
    
    login = (username, password) =>
        fetch('http://localhost:3005/api/login', {
            method: 'post',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
            },
            body: JSON.stringify({
                "username": username,
                "password": password
            })
        }).then(res => res.json());

    render() {
        const { onLogin } = this.props;
        return (

            <div>
                Email: <input onChange={this.handleChange.bind(this, 'username')} value={this.state.username} type="text"></input><br />
                password: <input onChange={this.handleChange.bind(this, 'password')} value={this.state.password} type="text"></input><br />
                <button onClick={() => this.handleLogin()} type="button">Click Me!</button>
                <div> {this.state.loginForm.error && <span>{this.state.loginForm.error}</span>}</div>
            </div>

        );
    }
    setError() {

    }
}

export default EamilLogin;
