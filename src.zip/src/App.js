import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import EmailComponent, { c } from './Email';
import faker from 'faker'
import EamilLogin from './EmailLogin';
import store from './store';

import { BrowserRouter as Router, Link, Route, Redirect } from 'react-router-dom'

const ShowWhen = (props) => props.condition ? props.children : null;

class App extends Component {
  state = {
    loginForm: {
      loading: false,
      ifLoggedIn: false
    },
    inbox: {
      loading: false,
      emails: []
    },
    inboxEmails: [

    ],
    sentEmails: [

    ],
    isInbox: true,
  }

  deletElement = (e, tabName) => {
    //e.counter++;
    //this.state.x++;
    if (e.important) {
      alert("You cannot delete important")
      //return;
    } else {

      this.state[tabName] = this.state[tabName].filter(em => em.counter != e.counter);
      this.setState(this.state) //Patch update
    }
  }

  componentDidMount() {
    let self = this;
    store.subscribe(() => {
      console.log(store.getState())

      this.setState(store.getState());
    })

    this.changeTab(true);
  }

  constructor() {
    super();
    // for (let i = 0; i < faker.random.number(); i++) {
    //   this.state.sentEmails.push(
    //     {
    //       counter: i,
    //       subject: faker.lorem.words(),
    //       message: faker.lorem.sentence(),
    //       from: faker.internet.email(),
    //       to: faker.name.findName(),
    //       important: faker.random.boolean()
    //     }
    //   );
    //   this.state.inboxEmails.push(
    //     {
    //       counter: i,
    //       subject: faker.lorem.words(),
    //       message: faker.lorem.sentence(),
    //       from: faker.internet.email(),
    //       to: faker.name.findName(),
    //       important: faker.random.boolean()
    //     }
    //   );
    // }
    this.setState(this.state)//whole update
    this.setState(this.state)//whole update
    //setInterval(this.increamentCounter,1);
  }

  renderEmails(tabName) {
    return this.state.inbox.emails.filter(email => email.subject).map(e =>
      e.subject ?
        <div>

          <div>
            <EmailComponent onDelete={() => this.deletElement(e, tabName)} obj={e} />
          </div>

        </div>
        : null

    )
  }

  changeTab(val) {
    //this.state.isInbox = val;
    store.dispatch({ type: 'EMAIL_LOAD_STARTED' });
    if (val) {
      this.loadData('inbox');

    } else {
      this.loadData('sent');

    }
  }

  loadData(val) {
    this.load(val).then(value => {
      if (value) {
        store.dispatch({ type: 'EMAIL_LOAD_COMPLETED', payload: value });
      } else {

      }
      console.log(value);
    })
  }

  load = (val) =>
    fetch(`http://localhost:3005/api/${val}`, {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      }
    }).then(res => res.json());
  handleLogout() {
    store.dispatch({ type: 'LOGOUT' });
  }


  render() {
    return (
      <Router>
        <div>
          <ShowWhen condition={this.state.loginForm.ifLoggedIn}>
            <Link to="/inbox">Inbox</Link>
            <Link to="/sent">Sent</Link>
            <button onClick={() => this.handleLogout()}>logout</button>
            <ShowWhen condition={this.state.isInbox}>
              <Redirect to="/inbox" />
            </ShowWhen>
            <ShowWhen condition={!this.state.isInbox}>
              <Redirect to="/sent" />
            </ShowWhen>
            <div> {this.state.inbox.loading && <span>Loading....</span>}</div>
          </ShowWhen>
          <ShowWhen condition={!this.state.loginForm.ifLoggedIn}>
            <Redirect to="/login" />
            {/* <EamilLogin onLogin={() => this.onLogin()}></EamilLogin> */}
          </ShowWhen>
          <Route path='/login' render={() => <EamilLogin />}></Route>
          <Route path='/inbox' render={() => this.renderEmails('inboxEmails')}></Route>
          <Route path='/sent' render={() => this.renderEmails('inboxEmails')}></Route>
          <Route path='/email' componen={EmailComponent}></Route>
        </div>
      </Router>
    );
  }

  onLogin() {
    this.state.loginForm.ifLoggedIn = true;
    this.setState(this.state)//whole update

  }
}

export default App;
