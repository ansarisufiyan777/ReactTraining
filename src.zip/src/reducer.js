import { combineReducers } from "redux";


const initState = {
    kloggedIn: false
}


const reducer = (state = initState, action) => {
    switch (action.type) {
        case 'LOGIN_COMPLETED':
            return {
                ...state, loginForm: {
                    ifLoggedIn: true,
                    error: null

                }
            };
        case 'LOGIN_STARTED':
            return {
                ...state, loginForm: {
                    loading: true,
                    error: "Loading..."
                }
            };
        case 'LOGIN_FAILED':
            return {
                ...state, loginForm: {
                    loading: false,
                    error: "Username or password is incorrect"
                }
            };
        case 'LOGOUT':
            return {
                ...state, loginForm: {
                    loginStarted: true,
                    ifLoggedIn:false
                }
            };
        case 'EMAIL_LOAD_STARTED':
            return {
                ...state,
                inbox: {
                    loading: true,
                    emails: []
                }
            };
        case 'EMAIL_LOAD_COMPLETED':
            return {
                ...state,
                inbox: {
                    loading: false,
                    emails: action.payload
                }
            };
        default:
            return false
    }
}





// const inboxReducer = (state = initState, action) => {
//     switch (action.type) {
    
//         case 'EMAIL_LOAD_STARTED':
//             return {
//                 ...state,
//                 inbox: {
//                     loading: true,
//                     emails: []
//                 }
//             };
//         case 'EMAIL_LOAD_COMPLETED':
//             return {
//                 ...state,
//                 inbox: {
//                     loading: false,
//                     emails: action.payload
//                 }
//             };
//         default:
//             return false
//     }
// }




// const loginReducer = (state = initState, action) => {
//     switch (action.type) {
//         case 'LOGIN_COMPLETED':
//             return {
//                 ...state, loginForm: {
//                     ifLoggedIn: true,
//                     error: null

//                 }
//             };
//         case 'LOGIN_STARTED':
//             return {
//                 ...state, loginForm: {
//                     loading: true,
//                     error: "Loading..."
//                 }
//             };
//         case 'LOGIN_FAILED':
//             return {
//                 ...state, loginForm: {
//                     loading: false,
//                     error: "Username or password is incorrect"
//                 }
//             };
//         case 'LOGOUT':
//             return {
//                 ...state, loginForm: {
//                     loginStarted: true
//                 }
//             };
//         default:
//             return false
//     }
// }


// const rootReducer = combineReducers({
//     loginForm:loginReducer,
//     inbox:inboxReducer
// })



export default reducer;