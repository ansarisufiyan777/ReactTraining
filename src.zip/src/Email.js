//Arror func
import React from 'react';
import { BrowserRouter as Router, Link, Route, Redirect } from 'react-router-dom'

const style = {'backgroundColor':'#ffeeee'};
const EmailComponent = ({obj={},onDelete})=>{
     
    return <div style={obj.important ? style : {}} className="email">
    From: {obj.from} <br/>
    TO: {obj.to} <br/>
    Subject: {obj.subject} <br/>
    Message: {obj.message} <br/>
    <Link to="email">Select</Link>
    <button onClick={() => this.handleDetail()}>select</button>
    </div>
  }


  export const c = "hi";

  export default EmailComponent;